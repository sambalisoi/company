<?php 
	class Office_model extends CI_model{
		public $table ="office";
		public function __contruct(){
			parent:: __contruct();
		}
		public function get_office(){
			$query = $this->db->query("select * from $this->table");
			$data = array();
			foreach ($query->result_array() as $value) {
				$data[]=$value;
			}
			return $data;
		}

		
	}
 ?>