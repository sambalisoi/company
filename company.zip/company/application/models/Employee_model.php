<?php 
	class Employee_model extends CI_model{
		public $table1 ="employee";
		public $table2 ="department";
		public $table3 ="position";
		
		public function __construct(){
			parent:: __construct();
		}

		public function get_employee(){
			$query = $this->db->query("select $this->table1.employee_id, $this->table1.name as employee, $this->table2.name as department, $this->table3.name as position, $this->table1.gender, $this->table1.dob, $this->table1.phone, $this->table1.fax, $this->table1.address, $this->table1.email, $this->table1.shift, $this->table1.begin_day, $this->table1.stop_day, $this->table1.id_number, $this->table1.granted_day, $this->table1.granted_place from $this->table1 inner join $this->table2 on $this->table1.department_id = $this->table2.department_id inner join $this->table3 on $this->table1.position_id = $this->table3.position_id");
			$result =$query->result_array();
			$data = array();
			foreach ($result as $value) {
				$data[] = $value;
			}
			return $data;
		}
		public function get_employee_by_id($id){
			$query =$this->db->query("select * from $this->table1 where employee_id =$id");
			$data = array();
			foreach ($query->result_array() as $value) {
				$data[] = $value;
			}
			return $data;
		}

		public function add_employee($data){
			$this->db->insert($this->table1,$data);
			
		}

		public function edit_employee($id,$data){
			// $this->db->where("employee_id", $id);
			$this->db->update($this->table1, $data, "employee_id = $id");
		}

		public function del_employee($id){
			$this->db->where("employee_id",$id);
			$this->db->delete($this->table1);
		}

		public function search($infor){
			$query = $this->db->query("select $this->table1.employee_id, $this->table1.name as employee, $this->table2.name as department, $this->table3.name as position, $this->table1.gender, $this->table1.dob, $this->table1.phone, $this->table1.fax, $this->table1.address, $this->table1.email, $this->table1.shift, $this->table1.begin_day, $this->table1.stop_day, $this->table1.id_number, $this->table1.granted_day, $this->table1.granted_place from $this->table1 inner join $this->table2 on $this->table1.department_id = $this->table2.department_id inner join $this->table3 on $this->table1.position_id = $this->table3.position_id where $this->table1.employee_id= '$infor' or $this->table1.name ='$infor' or $this->table1.email = '$infor' or $this->table2.name ='$infor' ");
			$result = $query->result_array();
			$data = array();
			foreach ($result as $value) {
				$data[] = $value;
			}
			return $data;
		}
		// ==================================================
		 public function get_department(){
		 	$query = $this->db->query("select * from $this->table2");
		 	$result = $query->result_array();
		 	$data = array();
		 	foreach ($result as $value) {
		 		$data[] = $value;
		 	}
		 	return $data;
		 }

		 public function get_position(){
		 	$query = $this->db->query("select * from $this->table3");
		 	$result = $query->result_array();
		 	$data = array();
		 	foreach ($result as $value) {
		 		$data[] = $value;
		 	}
		 	return $data;
		 }
	}
 ?>