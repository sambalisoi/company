<?php 
	class User_model extends CI_model{
		public $table ="user";

		public function __construct(){
			parent:: __construct();
		}

		public function get_password_by_username($username){
			$query = $this->db->query("select password from $this->table where username ='$username'");
			$result = $query->result_array();
			if($query->num_rows()>0){
				foreach ($result as $value) {
					$password = $value["password"];
				}
				return $password;
			}else{
				return NULL;
			}
			
			
		}
		public function get_password_by_email($email){
			$query = $this->db->query("select password from $this->table where email ='$email'");
			$result = $query->result_array();
			if($query->num_rows()>0){
				foreach ($result as  $value) {
					$password = $value["password"];
				}
					return $password;
			}else{
				return NULL;
			}
		}
	}
 ?>