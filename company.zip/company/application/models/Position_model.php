<?php 
	class Position_model extends CI_model{
		public $table1 = "position";
		public $table2 = "employee";
		public function __construct(){
			parent:: __construct();
		}

		public function get_position(){

			// $query = $this->db->query("select * from $this->table1");
			// $data = array();
			// foreach ($query->result_array() as $value) {
			// 	$data[] = $value;
			// }					
			// $data["employee"] = $this->get_employee();
			// return $data;
		}

		public function get_employee(){
			$query= $this->db->query("select position_id from $this->table1");
			$result = $query->result_array();
			$arr = array();
			$arr1 = array();
			foreach ($result as $value){
				// convert multi dim to one dim in array
				$position_id  = $value["position_id"];
				$query1= $this->db->query("select $this->table1.position_id, $this->table1.name, count($this->table2.employee_id) as employee from $this->table1 join $this->table2 on $this->table1.position_id =$this->table2.position_id where $this->table2.position_id = $position_id"); 
				$data[]= $query1->result_array();
			}
			$i = 0;
			var_dump(count($data));
			while($i <count($data)){
				
					$arr[]= $data[$i][0];	
				$i++;
			}
				
				return $arr;
		}

		
	}
 ?>