<?php 
	class Department_model extends CI_model{
		public $table = "department";
		public function __construct(){
			parent:: __construct();
		}

		public function get_department(){
			$query = $this->db->query("select * from $this->table");
			$data = array();
			foreach ($query->result_array() as $value) {
				$data[]=$value;
			}
			return $data;
		}
	}
 ?>