<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="description" content="A fully featured admin theme which can be used to build CRM, CMS, etc.">
        <meta name="author" content="Coderthemes">

        <link rel="shortcut icon" href="<?php echo base_url();?>/assets/images/favicon_1.ico">

        <title>Position Management</title>
        
        <!-- Plugin Css-->
        <link rel="stylesheet" href="<?php echo base_url();?>/assets/plugins/magnific-popup/dist/magnific-popup.css" />
        <link rel="stylesheet" href="<?php echo base_url();?>/assets/plugins/jquery-datatables-editable/datatables.css" />

        <link href="<?php echo base_url();?>/assets/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo base_url();?>/assets/css/core.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo base_url();?>/assets/css/components.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo base_url();?>/assets/css/icons.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo base_url();?>/assets/css/pages.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo base_url();?>/assets/css/responsive.css" rel="stylesheet" type="text/css" />

        <!-- HTML5 Shiv and Respond.js IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
        <![endif]-->

        <script src="<?php echo base_url();?>/assets/js/modernizr.min.js"></script>
        
    </head>


    <body class="fixed-left">

        <div class="animationload">
            <div class="loader"></div>
        </div>
        
        <!-- Begin page -->
        <div id="wrapper">

            <!-- Top Bar Start -->
            <div class="topbar">

                <!-- LOGO -->
                <div class="topbar-left">
                    <div class="text-center">
                        <a href="index" class="logo"><i class="icon-magnet icon-c-logo"></i><span>Acazia software</span></a>
                    </div>
                </div>

                <!-- Button mobile view to collapse sidebar menu -->
                <div class="navbar navbar-default" role="navigation">
                    <div class="container">
                        <div class="">
                            <div class="pull-left">
                                <button class="button-menu-mobile open-left">
                                    <i class="ion-navicon"></i>
                                </button>
                                <span class="clearfix"></span>
                            </div>

                            <form role="search" class="navbar-left app-search pull-left hidden-xs">
                           <input type="text" placeholder="Search..." class="form-control">
                           <a href=""><i class="fa fa-search"></i></a>
                      </form>


                            <ul class="nav navbar-nav navbar-right pull-right">
                                <li class="hidden-xs">
                                    <a href="#" id="btn-fullscreen" class="waves-effect waves-light"><i class="icon-size-fullscreen"></i></a>
                                </li>
                               
                                <li class="dropdown">
                                    <a href="" class="dropdown-toggle profile" data-toggle="dropdown" aria-expanded="true"><img src="<?php echo base_url();?>/assets/images/users/avatar-1.jpg" alt="user-img" class="img-circle"> </a>
                                    <ul class="dropdown-menu">                         
                                        <li><a href="logout"><i class="ti-power-off m-r-5"></i> Logout</a></li>
                                    </ul>
                                </li>
                            </ul>
                        </div>
                        <!--/.nav-collapse -->
                    </div>
                </div>
            </div>
            <!-- Top Bar End -->

            <!--=======================================================================  -->
            <!--  Left Sidebar Start -->
            <div class="left side-menu">
                <div class="sidebar-inner slimscrollleft">
                     <div class="user-details">
                        <div class="pull-left">
                            <img src="<?php echo base_url();?>/assets/images/users/avatar-1.jpg" alt="" class="thumb-md img-circle">
                        </div>
                        <div class="user-info">
                            <div class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false">Ptd-hanu</a>
                            </div>
                            <p class="text-muted m-0">Administrator</p>
                        </div>
                    </div>
                    <!--- Divider -->
                    <div id="sidebar-menu">
                        <ul>

                          <li class="text-muted menu-title">Navigation</li>

                            <li>
                                <a href="index" class="waves-effect "><i class="ti-home"></i> <span> Dashboard </span></a>
                            </li>

                            <li>
                                <a href="office" class="waves-effect"><i class="fa fa-briefcase"></i> <span>Office</span> </a>
                            </li>

                            <li>
                                <a href="department" class="waves-effect"><i class="fa fa-building-o"></i><span> Deparment</span></a>
                            </li>

                            <li >
                                <a href="employee" class="waves-effect"><i class="fa fa-user"></i><span class="label label-primary pull-right">6</span> <span> Employee</span> </a>
                            </li>

                            <li>
                                <a href="" class="waves-effect active"><i class="fa fa-user"></i><span>Position</span></a>
                            </li>
                        </ul>
                        <div class="clearfix"></div>
                    </div>
                    <div class="clearfix"></div>
                </div>
            </div>
            <!-- Left Sidebar End --> 
          <!--=================================================================================  -->
            <!-- Start right Content here -->
            <div class="content-page">
                <!-- Start content -->
                <div class="content">
                    <div class="container">

                        <!-- Page-Title -->
                        <div class="row">
                            <div class="col-sm-12">
                                <h4 class="page-title">Position Tables</h4><br>
                            </div>
                        </div>

                       <div class="panel">
                            
                            <div class="panel-body">
                                <div class="row">
                                    <div class="col-sm-6">
                                        <div class="m-b-30">
                                            <button id="addToTable" class="btn btn-default waves-effect waves-light">Add <i class="fa fa-plus"></i></button>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="">
                                    <table class="table table-striped" id="datatable-editable">
                                        <thead>
                                            <tr>
                                                <th>Postion ID</th>
                                                <th>Position name</th>
                                                <th>Employee Quantity </th>
                                                <th>Actions</th>
                                            </tr>
                                        </thead>
                                        <tbody>   
                                        <?php foreach($position as $value): ?>             
                                            <tr class="gradeU">
                                                <td><?=$value["position_id"]?></td>
                                                <td><?=$value["name"]?></td>
                                                <td><?=$value["employee"]?></td>
                                                <td class="actions">
                                                    <a href="#" class="hidden on-editing save-row"><i class="fa fa-save"></i></a>
                                                    <a href="#" class="hidden on-editing cancel-row"><i class="fa fa-times"></i></a>
                                                    <a href="#" class="on-default edit-row"><i class="fa fa-pencil"></i></a>
                                                    <a href="#" class="on-default remove-row"><i class="fa fa-trash-o"></i></a>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <!-- end: page -->

                        </div> <!-- end Panel -->
                        
                    </div> <!-- container -->
                               
                </div> <!-- content -->

                <footer class="footer">
                    2015 © Ubold.
                </footer>

            </div>
            
            <!-- End Right content here -->
            <!-- ============================================================== -->
            <!-- MODAL -->
            <div id="dialog" class="modal-block mfp-hide">
                <section class="panel panel-info panel-color">
                    <header class="panel-heading">
                        <h2 class="panel-title">Are you sure?</h2>
                    </header>
                    <div class="panel-body">
                        <div class="modal-wrapper">
                            <div class="modal-text">
                                <p>Are you sure that you want to delete this row?</p>
                            </div>
                        </div>

                        <div class="row m-t-20">
                            <div class="col-md-12 text-right">
                                <button id="dialogConfirm" class="btn btn-primary waves-effect waves-light">Confirm</button>
                                <button id="dialogCancel" class="btn btn-default waves-effect">Cancel</button>
                            </div>
                        </div>
                    </div>
                    
                </section>
            </div>
            <!-- end Modal -->

        
            
                      
        </div>
        <!-- END wrapper -->


    
        <script>
            var resizefunc = [];
        </script>

        <!-- jQuery  -->
        <script src="<?php echo base_url();?>/assets/js/jquery.min.js"></script>
        <script src="<?php echo base_url();?>/assets/js/bootstrap.min.js"></script>
        <script src="<?php echo base_url();?>/assets/js/detect.js"></script>
        <script src="<?php echo base_url();?>/assets/js/fastclick.js"></script>
        <script src="<?php echo base_url();?>/assets/js/jquery.slimscroll.js"></script>
        <script src="<?php echo base_url();?>/assets/js/jquery.blockUI.js"></script>
        <script src="<?php echo base_url();?>/assets/js/waves.js"></script>
        <script src="<?php echo base_url();?>/assets/js/wow.min.js"></script>
        <script src="<?php echo base_url();?>/assets/js/jquery.nicescroll.js"></script>
        <script src="<?php echo base_url();?>/assets/js/jquery.scrollTo.min.js"></script>
        <!-- jQuery  -->
       <script src="<?php echo base_url();?>/assets/js/jquery.core.js"></script>
        <script src="<?php echo base_url();?>/assets/js/jquery.app.js"></script>

        <!-- Examples -->
        <script src="<?php echo base_url();?>/assets/plugins/magnific-popup/dist/jquery.magnific-popup.min.js"></script>
        <script src="<?php echo base_url();?>/assets/plugins/jquery-datatables-editable/jquery.dataTables.js"></script> 
        <script src="<?php echo base_url();?>/assets/plugins/datatables/dataTables.bootstrap.js"></script>
        <script src="<?php echo base_url();?>/assets/plugins/tiny-editable/mindmup-editabletable.js"></script>
        <script src="<?php echo base_url();?>/assets/plugins/tiny-editable/numeric-input-example.js"></script>
        
        
        <script src="<?php echo base_url();?>/assets/pages/datatables.editable.init.js"></script>
        
        <script>
            $('#mainTable').editableTableWidget().numericInputExample().find('td:first').focus();
            
        </script>
        

    </body>
</html>