<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="description" content="A fully featured admin theme which can be used to build CRM, CMS, etc.">
        <meta name="author" content="Coderthemes">

        <link rel="shortcut icon" href="<?php echo base_url();?>/assets/images/favicon_1.ico">

        <title>Employee Management</title>
       
        <link href="<?php echo base_url();?>/assets/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo base_url();?>/assets/css/core.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo base_url();?>/assets/css/components.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo base_url();?>/assets/css/icons.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo base_url();?>/assets/css/pages.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo base_url();?>/assets/css/responsive.css" rel="stylesheet" type="text/css" />
        <script src="<?php echo base_url();?>/assets/js/modernizr.min.js"></script>
         <!-- foo table -->
       <link href="<?php echo base_url();?>/assets/plugins/footable/css/footable.core.css" rel="stylesheet">
        <link href="<?php echo base_url();?>/assets/plugins/bootstrap-select/dist/css/bootstrap-select.min.css" rel="stylesheet" />
        
        <!-- sweet-alert -->
        <link href="<?php echo base_url();?>/assets/plugins/sweetalert/dist/sweetalert.css" rel="stylesheet" type="text/css">
    </head>


    <body class="fixed-left">

        <div class="animationload">
            <div class="loader"></div>
        </div>
        
        <!-- Begin page -->
        <div id="wrapper">

            <!-- Top Bar Start -->
            <div class="topbar">

                <!-- LOGO -->
                <div class="topbar-left">
                    <div class="text-center">
                        <a href="index" class="logo"><i class="icon-magnet icon-c-logo"></i><span>Acazia software</span></a>
                    </div>
                </div>

                <!-- Button mobile view to collapse sidebar menu -->
                <div class="navbar navbar-default" role="navigation">
                    <div class="container">
                        <div class="">
                            <div class="pull-left">
                                <button class="button-menu-mobile open-left">
                                    <i class="ion-navicon"></i>
                                </button>
                                <span class="clearfix"></span>
                            </div>

                            <form role="search" class="navbar-left app-search pull-left hidden-xs">
                           <input type="text" placeholder="Search..." class="form-control">
                           <a href=""><i class="fa fa-search"></i></a>
                      </form>


                            <ul class="nav navbar-nav navbar-right pull-right">
                                <li class="hidden-xs">
                                    <a href="#" id="btn-fullscreen" class="waves-effect waves-light"><i class="icon-size-fullscreen"></i></a>
                                </li>
                               
                                <li class="dropdown">
                                    <a href="" class="dropdown-toggle profile" data-toggle="dropdown" aria-expanded="true"><img src="<?php echo base_url();?>/assets/images/users/avatar-1.jpg" alt="user-img" class="img-circle"> </a>
                                    <ul class="dropdown-menu">                         
                                        <li><a href="logout"><i class="ti-power-off m-r-5"></i> Logout</a></li>
                                    </ul>
                                </li>
                            </ul>
                        </div>
                        <!--/.nav-collapse -->
                    </div>
                </div>
            </div>
            <!-- Top Bar End -->

            <!-- ============================================================ -->
            
            <!-- Left Sidebar Start -->
            <div class="left side-menu">
                <div class="sidebar-inner slimscrollleft">
                     <div class="user-details">
                        <div class="pull-left">
                            <img src="<?php echo base_url();?>/assets/images/users/avatar-1.jpg" alt="" class="thumb-md img-circle">
                        </div>
                        <div class="user-info">
                            <div class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false">Ptd-hanu</a>
                            </div>
                            <p class="text-muted m-0">Administrator</p>
                        </div>
                    </div>
                    <!--- Divider -->
                    <div id="sidebar-menu">
                        <ul>

                          <li class="text-muted menu-title">Navigation</li>

                            <li>
                                <a href="index" class="waves-effect"><i class="ti-home"></i> <span> Dashboard </span></a>
                            </li>

                            <li>
                                <a href="office" class="waves-effect"><i class="fa fa-briefcase"></i> <span>Office</span> </a>
                            </li>

                            <li>
                                <a href="department" class="waves-effect"><i class="fa fa-building-o"></i><span> Deparment</span></a>
                            </li>

                            <li >
                                <a href="employee" class="waves-effect active"><i class="fa fa-user"></i><span class="label label-primary pull-right">6</span> <span> Employee</span> </a>
                            </li>

                            <li>
                                <a href="position" class="waves-effect"><i class="fa fa-user"></i><span>Position</span></a>
                            </li>
                        </ul>
                        <div class="clearfix"></div>
                    </div>
                    <div class="clearfix"></div>
                </div>
            </div>
            <!-- Left Sidebar End --> 

           <!-- ============================================================== -->
            
            <!-- Start right Content here -->
            <div class="content-page">
                <!-- Start content -->
                <div class="content">
                    <div class="container">

                        <!-- Page-Title -->
                        <div class="row">
                            <div class="col-sm-12">
                                <h4 class="page-title">&nbsp;Employee Tables</h4><br>
                            </div>
                        </div>


                       <div class="row">
                            <div class="col-sm-12">
                                
                                <div class="card-box">
                                    <!-- <h4 class="m-t-0 header-title"><b>Pagination</b></h4>
                                    <p class="text-muted m-b-30 font-13">
                                        include pagination in your FooTable.
                                    </p> -->
                                     <div class="row">
                                        <div class="col-sm-6">
                                                <div class="m-b-30">
                                                    <button id="addToTable" class="btn btn-default"><a href="add_employee" style="color:white;">Add <i class="fa fa-plus"></i></a> </button>
                                                </div>
                                            </div>
                                        </div>
                                    
                                        <div class="form-inline m-b-20">
                                            <div class="row">
                                                <div class="col-sm-6 text-xs-center">
                                                    <div class="form-group">
                                                        <label class="control-label m-r-5">Show</label>
                                                        <select id="demo-foo-filter-status" class="form-control input-sm">
                                                            <option value="5">5</option>
                                                           <!--  <option value="10">10</option>
                                                            <option value="15">15</option>
                                                            <option value="20">20<option> -->
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="col-sm-6 text-xs-center text-right">
                                                    <form class="form-horizontal m-t-20" action="search" method="post">
                                                        <div class="form-group">
                                                            <input id="demo-foo-search" type="text" placeholder="Search" class="form-control input-sm" autocomplete="on" name="search" value="<?php echo ($this->input->post('search'))?$this->input->post('search'):''; ?>">
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>

                                    <table id="demo-foo-pagination" class="table m-b-0 toggle-arrow-tiny" data-page-size="5">
                                        <thead>
                                            <tr>
                                                <th data-toggle="true">Employee ID</th>
                                                <th>Employee Name </th>
                                                <th>Department Name</th>
                                                <th data-hide="phone">Position Name</th>
                                                <th data-hide="all">Gender</th>
                                                <th data-hide="all">DOB </th>
                                                <th data-hide="all">Telephone</th>
                                                 <th data-hide="all">Fax</th>
                                                 <th data-hide="all">Address</th>
                                                <th data-hide="all">Email</th>>               
                                                <th data-hide="all">Working Type</th>
                                                <th data-hide="all">Began Day</th>
                                                <th data-hide="all">Stoped Day</th>
                                                <th data-hide="all"> Identify Number</th>
                                                <th data-hide="all">Granted Day</th>
                                                <th data-hide="all">Granted Place</th>
                                                <th>Action</th>                        
                                            </tr>
                                        </thead>
                                        <tbody>
                                        <?php foreach($employee as $value): ?>
                                            <tr>
                                                <td><?=$value["employee_id"] ?></td>
                                                <td><?=$value["employee"] ?></td>
                                                <td><?=$value["department"]   ?></td>
                                                <td><?=$value["position"] ?></td>
                                                <td><?php
                                                    if($value["gender"]==0){
                                                        echo "Male";
                                                    }else{
                                                        echo "Female";
                                                    }
                                                 ?></td>
                                                <td><?=$value["dob"] ?></td>
                                                <td><?=$value["phone"] ?></td>
                                                <td><?=$value["fax"] ?></td>
                                                <td><?=$value["address"] ?></td>
                                                <td><?=$value["email"] ?></td>
                                                <td>
                                                    <?php 
                                                        if($value["shift"] ==0){
                                                            echo "Full-time";
                                                        }else{
                                                            echo "Part-time";
                                                        }
                                                    ?>
                                                 </td>
                                                <td><?=$value["begin_day"] ?></td>
                                                <td><?=$value["stop_day"] ?></td>
                                                <td><?=$value["id_number"] ?></td>
                                                <td><?=$value["granted_day"] ?></td>
                                                <td><?=$value["granted_place"] ?></td>
                                                <td class="actions">
                                                    <button class="btn btn-link btn-xs"><a href="edit_employee/<?=$value['employee_id'] ?>"><i class="fa fa-pencil" aria-hidden="true"></i></a></button>&nbsp;
                                                   <button class="btn btn-link btn-xs"><a href="del_employee/<?=$value['employee_id'] ?>" class="on-default remove-row" onclick="return window.confirm('Are you sure?');"><i class="fa fa-trash-o"></i></a></button>
                                                </td>
                                            </tr>
                                            <?php endforeach; ?>
                                        </tbody>
                                        <tfoot>
                                            <tr>
                                                <td colspan="5">
                                                    <div class="text-right">
                                                        <ul class="pagination pagination-split m-t-30"></ul>
                                                    </div>
                                                </td>
                                            </tr>
                                        </tfoot>
                                    </table>
                                </div>
                            </div>
                        </div> 
                    </div> <!-- container -->
                               
                </div> <!-- content -->

                <footer class="footer">
                    2015 © Ubold.
                </footer>

            </div>
            <!-- End Right content here -->

            <!-- ============================================================== -->
            

                      
        </div>
        <!-- END wrapper -->


    
        <script>
            var resizefunc = [];
        </script>

        <!-- jQuery  -->
        <script src="<?php echo base_url();?>/assets/js/jquery.min.js"></script>
        <script src="<?php echo base_url();?>/assets/js/bootstrap.min.js"></script>
        <script src="<?php echo base_url();?>/assets/js/detect.js"></script>
        <script src="<?php echo base_url();?>/assets/js/fastclick.js"></script>
        <script src="<?php echo base_url();?>/assets/js/jquery.slimscroll.js"></script>
        <script src="<?php echo base_url();?>/assets/js/jquery.blockUI.js"></script>
        <script src="<?php echo base_url();?>/assets/js/waves.js"></script>
        <script src="<?php echo base_url();?>/assets/js/wow.min.js"></script>
        <script src="<?php echo base_url();?>/assets/js/jquery.nicescroll.js"></script>
        <script src="<?php echo base_url();?>/assets/js/jquery.scrollTo.min.js"></script>
        <!-- jQuery  -->
       <script src="<?php echo base_url();?>/assets/js/jquery.core.js"></script>
        <script src="<?php echo base_url();?>/assets/js/jquery.app.js"></script>

        <!--FooTable-->
        <script src="<?php echo base_url();?>/assets/plugins/footable/js/footable.all.min.js"></script>
        
        <script src="<?php echo base_url();?>/assets/plugins/bootstrap-select/dist/js/bootstrap-select.min.js" type="text/javascript"></script>
        <!--FooTable Example-->
        <script src="<?php echo base_url();?>/assets/pages/jquery.footable.js"></script>

         <!-- Sweet-Alert  -->
        <script src="<?php echo base_url();?>/assets/plugins/sweetalert/dist/sweetalert.min.js"></script>
        <script src="<?php echo base_url();?>/assets/pages/jquery.sweet-alert.init.js"></script>
        

    </body>
</html>