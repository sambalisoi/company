<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="description" content="A fully featured admin theme which can be used to build CRM, CMS, etc.">
        <meta name="author" content="Coderthemes">

        <link rel="shortcut icon" href="<?php echo base_url();?>/assets/images/favicon_1.ico">

        <title>Add Information</title>
        
        <!--Morris Chart CSS -->
        <!-- <link rel="stylesheet" href="<?php echo base_url();?>/assets/plugins/morris/morris.css">
        <link href="<?php echo base_url();?>/assets/plugins/sweetalert/dist/sweetalert.css" rel="stylesheet" type="text/css"> -->
        <!--  -->
        <link href="<?php echo base_url();?>/assets/plugins/bootstrapvalidator/src/css/bootstrapValidator.css" rel="stylesheet" type="text/css" />
        <!--  -->

        <link href="<?php echo base_url();?>/assets/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo base_url();?>/assets/css/core.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo base_url();?>/assets/css/components.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo base_url();?>/assets/css/icons.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo base_url();?>/assets/css/pages.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo base_url();?>/assets/css/responsive.css" rel="stylesheet" type="text/css" />

        <!-- HTML5 Shiv and Respond.js IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
        <![endif]-->

        <script src="<?php echo base_url();?>/assets/js/modernizr.min.js"></script>
        
    </head>


    <body class="fixed-left">
s
        <!-- Begin page -->
        <div id="wrapper">

            <!-- Top Bar Start -->
            <div class="topbar">

                <!-- LOGO -->
                <div class="topbar-left">
                    <div class="text-center">
                        <a href="index" class="logo"><i class="icon-magnet icon-c-logo"></i><span>Acazia software</span></a>
                    </div>
                </div>

                <!-- Button mobile view to collapse sidebar menu -->
                <div class="navbar navbar-default" role="navigation">
                    <div class="container">
                        <div class="">
                            <div class="pull-left">
                                <button class="button-menu-mobile open-left">
                                    <i class="ion-navicon"></i>
                                </button>
                                <span class="clearfix"></span>
                            </div>

                            <form role="search" class="navbar-left app-search pull-left hidden-xs">
                           <input type="text" placeholder="Search..." class="form-control">
                           <a href=""><i class="fa fa-search"></i></a>
                      </form>


                            <ul class="nav navbar-nav navbar-right pull-right">
                                <li class="hidden-xs">
                                    <a href="#" id="btn-fullscreen" class="waves-effect waves-light"><i class="icon-size-fullscreen"></i></a>
                                </li>
                               
                                <li class="dropdown">
                                    <a href="" class="dropdown-toggle profile" data-toggle="dropdown" aria-expanded="true"><img src="<?php echo base_url();?>/assets/images/users/avatar-1.jpg" alt="user-img" class="img-circle"> </a>
                                    <ul class="dropdown-menu">                         
                                        <li><a href="logout"><i class="ti-power-off m-r-5"></i> Logout</a></li>
                                    </ul>
                                </li>
                            </ul>
                        </div>
                        <!--/.nav-collapse -->
                    </div>
                </div>
            </div>
            <!-- Top Bar End -->


            <!-- ========== Left Sidebar Start ========== -->

            <div class="left side-menu">
                <div class="sidebar-inner slimscrollleft">
                     <div class="user-details">
                        <div class="pull-left">
                            <img src="<?php echo base_url();?>/assets/images/users/avatar-1.jpg" alt="" class="thumb-md img-circle">
                        </div>
                        <div class="user-info">
                            <div class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false">Ptd-hanu</a>
                            </div>
                            <p class="text-muted m-0">Administrator</p>
                        </div>
                    </div>
                    <!--- Divider -->
                    <div id="sidebar-menu">
                        <ul>

                          <li class="text-muted menu-title">Navigation</li>

                            <li>
                                <a href="index" class="waves-effect "><i class="ti-home"></i> <span> Dashboard </span></a>
                            </li>

                            <li>
                                <a href="office" class="waves-effect"><i class="fa fa-briefcase"></i> <span>Office</span> </a>
                            </li>

                            <li>
                                <a href="department" class="waves-effect"><i class="fa fa-building-o"></i><span> Deparment</span></a>
                            </li>

                            <li >
                                <a href="employee" class="waves-effect active"><i class="fa fa-user"></i><span class="label label-primary pull-right">6</span> <span> Employee</span> </a>
                            </li>

                            <li>
                                <a href="position" class="waves-effect"><i class="fa fa-user"></i><span>Position</span></a>
                            </li>
                        </ul>
                        <div class="clearfix"></div>
                    </div>
                    <div class="clearfix"></div>
                </div>
            </div>
            <!-- Left Sidebar End --> 
            <!-- start content -->
            <div class="content-page">
                <div class="content">
                    <div class="container">

                        <!-- Page-Title -->
                        <!-- <div class="row">
                            <div class="col-sm-12">
                                <h4 class="page-title">E</h4>
                                <ol class="breadcrumb">
                                    <li><a href="#">Ubold</a></li>
                                    <li><a href="#">Forms</a></li>
                                    <li class="active">Form Validation</li>
                                </ol>
                            </div>
                        </div> -->
                        
                        <div class="row">
                                        <div class="col-lg-6">
                                            <div class="card-box">
                                                <h4 class="m-t-0 header-title"><b>Employee Information</b></h4>
                                                <br>
                                                           <?php echo validation_errors(); ?>      
                                                <form action="add_employee" method="post" data-parsley-validate novalidate>
                                                    
                                                    <div class="row">
                                                        <div class="form-group col-sm-6">
                                                          <label for="sel1">Department </label>
                                                          <select class="form-control" name="department_id" required="">
                                                          <?php foreach($department as $row1): ?>
                                                            <option value="<?=$row1['department_id']?>"><?=$row1['name']?></option>
                                                            <?php endforeach; ?>
                                                          </select>
                                                        </div>
                                                        <div class="form-group col-sm-6">
                                                          <label for="sel1">Position  </label>
                                                          <select class="form-control" name="position_id" required="">
                                                             <?php foreach ($position as $row2): ?>
                                                            <option value="<?=$row2['position_id']?>"><?=$row2['name']?></option>
                                                            <?php endforeach; ?>
                                                          </select>
                                                        </div>
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="name">Employee Name</label>
                                                        
                                                        <input type="text" name="name" parsley-trigger="change" required placeholder="Enter employee name" class="form-control" id="name" value="<?php echo set_value('name');?>">
                                                    </div>
                                                     
                                                    <div class="form-group row">
                                                        <label for="gender" class="col-sm-2 control-label">Gender </label>
                                                        <div class="col-sm-3">
                                                            <label class="radio-inline"> <input type="radio" name="gender" value="0" required="" checked >Male</label>
                                                            <label class="radio-inline"> <input type="radio" name="gender" value="1" >Female</label>
                                                        </div>
                                                        <label for="dob" class="col-sm-3">Date of birth </label>
                                                            <div class="col-sm-4">
                                                                <input type="date" name="dob" parsley-trigger="change" required="" placeholder="Enter date of brith" class="form-control" id="dob" value="<?php echo set_value('dob');?>">
                                                            </div>
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="address">Address</label>
                                                        <input type="text" name="address" parsley-trigger="change" required="" placeholder="Enter Address"  class="form-control" id="address"  value="<?php echo set_value('address');?>">
                                                    </div>
                                                    <div class="row">
                                                        <div class="form-group col-sm-6">
                                                            <label for="telephone">Telephone</label>
                                                            <input type="tel" name="phone" parsley-trigger="change" required="" placeholder="Enter Telephone"  class="form-control" id="telephone" value="<?php echo set_value('phone');?>" >
                                                        </div>
                                                        <div class="form-group col-sm-6">
                                                            <label for="Fax">Fax</label>
                                                            <input type="tel" name="fax" parsley-trigger="change" placeholder="Enter Fax"  class="form-control" id="fax"  value="<?php echo set_value('fax');?>">
                                                        </div>
                                                    </div>
                                                    
                                                    <div class="form-group">
                                                        <label for="email">Email</label>
                                                        <input type="email" name="email" parsley-trigger="change" required="" placeholder="Enter Email" class="form-control" id="email"  value="<?php echo set_value('email');?>" >
                                                    </div>
                                                    
                                                    
                                                    <div class="form-group row">
                                                        <label for="gender" class="col-sm-4  control-label">Woking Shift </label>
                                                        <label class="radio-inline col-sm-4"> <input type="radio" name="shift" value="0" required="" checked>Full Time</label>
                                                         <label class="radio-inline col-sm-3"> <input type="radio" name="shift" value="1">Part Time</label>
                                                    </div>
                                                    <div class="row">
                                                        <div class="form-group col-sm-6">
                                                            <label for="begin">Beginning  Day</label>
                                                            <input type="date" name="begin_day" parsley-trigger="change" required="" placeholder="Enter Beginning Working Day"  class="form-control" id="begin" value="<?php echo set_value('begin_day');?>" >
                                                        </div> 
                                                        <div class="form-group  col-sm-6">
                                                            <label for="stop_day">Stopped Day</label>
                                                            <input type="date" name="stop_day" parsley-trigger="change"  required="" placeholder="Enter Stopped Day" class="form-control" id="stop_day"  value="<?php echo set_value('stop_day');?>"  >
                                                        </div>
                                                    </div>
                                                    <div class="row">
                                                         <div class="form-group col-sm-6">
                                                            <label for="identify">Identify Number</label>
                                                            <input type="number" name="id_number" parsley-trigger="change" required="" placeholder="Enter Identify Number"  class="form-control" id="identify" min = 1  value="<?php echo set_value('id_number');?>">
                                                        </div>
                                                        <div class="form-group col-sm-6">
                                                            <label for="granted Date">Granted Day</label>
                                                            <input type="date" name="granted_day" parsley-trigger="change" required="" placeholder="Enter Granted Date"  class="form-control" id="granted date"  value="<?php echo set_value('granted_day');?>" >
                                                        </div>
                                                    </div>
                                                   
                                                    <div class="form-group">
                                                        <label for="granted place">Granted Place</label>
                                                        <input type="text" name="granted_place" parsley-trigger="change" required="" placeholder="Enter Granted Place"  class="form-control" id="granted place"  value="<?php echo set_value('granted_place');?>" >
                                                    </div>

                                                   <div class="form-group text-right m-b-0">
                                                        <button class="btn btn-primary waves-effect waves-light" type="submit" name="submit">
                                                            Submit
                                                        </button>
                                                        <button class="btn btn-default waves-effect waves-light m-l-5"><a href="employee" style="color:white;">Cancel</a> </button>
                                                    </div>
                                                    
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
               

                <footer class="footer text-right">
                    2015 © Ubold.
                </footer>

            </div>
          </div>
        <!-- END wrapper -->


    
        <script>
            var resizefunc = [];
        </script>

        <!-- jQuery  -->
        <script src="<?php echo base_url();?>/assets/js/jquery.min.js"></script>
        <script src="<?php echo base_url();?>/assets/js/bootstrap.min.js"></script>
        <script src="<?php echo base_url();?>/assets/js/detect.js"></script>
        <script src="<?php echo base_url();?>/assets/js/fastclick.js"></script>
        <script src="<?php echo base_url();?>/assets/js/jquery.slimscroll.js"></script>
        <script src="<?php echo base_url();?>/assets/js/jquery.blockUI.js"></script>
        <script src="<?php echo base_url();?>/assets/js/waves.js"></script>
        <script src="<?php echo base_url();?>/assets/js/wow.min.js"></script>
        <script src="<?php echo base_url();?>/assets/js/jquery.nicescroll.js"></script>
        <script src="<?php echo base_url();?>/assets/js/jquery.scrollTo.min.js"></script>
        <!-- jQuery  -->
         <script src="assets/js/jquery.core.js"></script>
        <script src="assets/js/jquery.app.js"></script>

        
        <script type="text/javascript" src="assets/plugins/parsleyjs/dist/parsley.min.js"></script>
        
        
        <script type="text/javascript">
            $(document).ready(function() {
                $('form').parsley();
            });
        </script>

    
    
        

    </body>
</html>