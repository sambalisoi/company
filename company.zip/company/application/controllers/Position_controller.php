<?php 
	class Position_controller extends CI_controller{
		public function __construct(){
			parent:: __construct();
			$this->load->model("position_model");
		}

		public function index(){
			$data["position"] =$this->position_model->get_employee();
			// var_dump($data);
			$this->load->view("view_position",$data);
		}
	}
 ?>