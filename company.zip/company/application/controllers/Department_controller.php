<?php 
	class Department_controller extends CI_controller{
		public function __construct(){
			parent:: __construct();
			$this->load->model("department_model");

		}

		public function index(){
			$data["department"]= $this->department_model->get_department();
			$this->load->view("view_department",$data);
		}
	}
 ?>