<?php 
	class Office_controller extends CI_controller{
		public function __construct(){
			parent:: __construct();
			 $this->load->model("office_model");

		}

		public function index(){
			$data["office"] = $this->office_model->get_office();
			$this->load->view("view_office",$data);
		}
		
	}
 ?>