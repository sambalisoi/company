<?php 
	class Employee_controller extends CI_controller{
		public function __construct(){
			parent:: __construct();
			$this->load->model("employee_model");
		}

		public function index(){
			$data["employee"] = $this->employee_model->get_employee();

			$this->load->view("view_employee",$data);
		}

		public function add_employee(){
			$submit = $this->input->post("submit");
			if(!isset($submit)){
				$data["department"] = $this->employee_model->get_department();
				$data["position"] = $this->employee_model->get_position();
				$this->load->view("view_add_employee",$data);
			}else{
				$check = $this->validation();
				if($check == FAlSE ){
					$data["department"] = $this->employee_model->get_department();
					$data["position"] = $this->employee_model->get_position();
					$this->load->view("view_add_employee",$data);
				}else{
					$data = array(
					'department_id'=> $this->input->post("department_id"),
					'position_id' => $this->input->post("position_id"),
					'name' => $this->input->post("name"),
					'gender' =>$this->input->post("gender"),
					'dob'=> $this->input->post("dob"),
					'phone'=> $this->input->post("phone"),
					'fax' => $this->input->post("fax"),
					'address' => $this->input->post("address"),
					'email' =>$this->input->post("email"),
					'shift'=> $this->input->post("shift"),
					'begin_day'=> $this->input->post("begin_day"),
					'stop_day' => $this->input->post("stop_day"),
					'id_number' => $this->input->post("id_number"),
					'granted_day' => $this->input->post("granted_day"),
					'granted_place' =>$this->input->post("granted_place")
					);
					$this->employee_model->add_employee($data);
					redirect("employee");
				}
			}
		}

		public function edit_employee(){
			$submit = $this->input->post("submit");
			if(!isset($submit)){
				$id =$this->uri->segment(2);
				$data['employee_id'] = $id;
				$data["department"] = $this->employee_model->get_department();
				$data["position"] = $this->employee_model->get_position();
				$data["employee"] =$this->employee_model->get_employee_by_id($id);

				$this->load->view("view_edit_employee",$data);
			}else{
				$id = $this->uri->segment(2);
				$check = $this->validation();
				if($check == FAlSE ){
				$data['employee_id'] = $id;
				$data["department"] = $this->employee_model->get_department();
				$data["position"] = $this->employee_model->get_position();
				$data["employee"] =$this->employee_model->get_employee_by_id($id);
				// echo "submit";
				$this->load->view("view_edit_employee",$data);
				}else{
					$employee_id = $this->uri->segment(2);
					$data = array(
					'department_id'=> $this->input->post("department_id"),
					'position_id' => $this->input->post("position_id"),
					'name' => $this->input->post("name"),
					'gender' =>$this->input->post("gender"),
					'dob'=> $this->input->post("dob"),
					'phone'=> $this->input->post("phone"),
					'fax' => $this->input->post("fax"),
					'address' => $this->input->post("address"),
					'email' =>$this->input->post("email"),
					'shift'=> $this->input->post("shift"),
					'begin_day'=> $this->input->post("begin_day"),
					'stop_day' =>$this->input->post("stop_day"),
					'id_number' =>$this->input->post("id_number"),
					'granted_day' => $this->input->post("granted_day"),
					'granted_place' =>$this->input->post("granted_place")
					);


					$this->employee_model->edit_employee($employee_id, $data);
					
					redirect("employee");
				}
			}
		}

		public function del_employee(){
			$employee_id = $this->uri->segment(2);
			var_dump($employee_id);
			$this->employee_model->del_employee($employee_id);
			redirect("employee");
		}

		public function search(){
			$search = $this->input->post("search");
			$data["employee"] = $this->employee_model->search($search);
			$this->load->view("view_employee",$data);
		}

		public function validation(){
			$this->form_validation->set_rules("name", "Employee name","trim|required|min_length[6]|max_length[50]|alpha_numeric_spaces",
				array(
					"required" => "This field is required ",
					"min_length[6]" =>"Employee name is not shorter than 6 characters",
					"max_length[50]" =>"Employee name is not longer than 50 characters",
					"alpha_numeric_spaces" =>" Employee name only contains alpha-numeric characters or spaces"
				));

			$this->form_validation->set_rules("dob", "Date of birth","trim|required",
				array(
					"required" => "This field is required ",
				));


			$this->form_validation->set_rules("address", "Address","trim|required|max_length[200]|alpha_numeric_spaces",
				array(
					"required" => "This field is required ",
					"max_length[200]" =>"Address is not longer than 200 characters",
					"alpha_numeric_spaces" =>" Address only contains alpha-numeric characters or spaces"
				));


			$this->form_validation->set_rules("phone", "Telephone Number","trim|required|max_length[20]|numeric",
				array(
					"required" => "This field is required ",
					"max_length[200]" =>"Telephone number is not longer than 20 numberic characters",
					"numeric" =>" Telephone Number only contains numeric characters"
				));


			$this->form_validation->set_rules("fax", "Fax Number","trim|max_length[20]|numeric",
				array(
					"max_length[200]" =>"Fax number is not longer than 20 numberic characters",
					"numeric" =>" Fax number only contains numeric characters"
				));


			$this->form_validation->set_rules("email", "Email","trim|required|max_length[200]|valid_email",
				array(
					"required" => "This field is required ",
					"max_length[200]" =>"Email is not longer than 200 characters",
				));

			$this->form_validation->set_rules("begin_day", "Beginning Day","trim|required",
				array(
					"required" => "This field is required "
				));
			
			$this->form_validation->set_rules("id_number", "Identify Number","trim|required|greater_than[0]|numeric",
				array(
					"required" => "This field is required ",
					"greater_than[0]" => "The Identify number is greater than 0",
					"numeric" =>" Identify Number only contains numeric characters"
				));

			$this->form_validation->set_rules("granted_day", "Granted Day","trim|required",
				array(
					"required" => "This field is required ",
				));

			$this->form_validation->set_rules("granted_place", "Granted Place","trim|required|max_length[200]|alpha_numeric_spaces",
				array(
					"required" => "This field is required ",
					"max_length[200]" =>" Granted Place is not longer than 200 characters",
					"alpha_numeric_spaces" =>" Granted Place only contains alpha-numeric characters or spaces"
				));
			$check = $this->form_validation->run();
			return $check;

		}
	}
 ?>