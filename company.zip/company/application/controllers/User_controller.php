<?php 
	class User_controller extends CI_controller{
		public function __construct(){
			parent:: __construct();
			$this->load->model("user_model");
				
		}

		public function index(){
		if(!isset($this->session->username)){
				$this->form_handle();
			}else{
				$this->load->view("view_dashboard");
			}
				

		}

		public function form_handle(){
			$username = $this->input->post("username");
			$password = $this->input->post("password");

			if($username == NULL || $password == NULL){
				$this->load->view("view_login");
			}else{
				$password_db = $this->user_model->get_password_by_username($username);

				if($password_db != $password){
					$this->load->view("view_login");
				}else{
					$this->session->username =$username;
					redirect("index");
				}
			}

		}

		public function register(){
			$email = $this->input->post("email");
			if($email == NULL){
				$this->load->view("view_register");
			}else{
				$password_db = $this->user_model->get_password_by_email($email);
				if($password_db == NULL){
					$this->load->view("view_register");
				}else{
					
					// send password to email
					$config = array(
						"protocol" =>"smtp",
						"smtp_host" => "ssl://smtp.googlemail.com",
						"smtp_port" => 465,
						"smtp_user" =>"sambalisoi@gmail.com",
						"smtp_pass" =>"29081994ptd"
					);
					$this->load->library("email", $config);
					$this->email->set_newline("\r\n");

					$this->email->from('sambalisoi@gmai.com', 'ptdhanu');
					$this->email->to($email);

					$this->email ->subject('Email Test');
					$this->email->message($password_db);

					if($this->email->send()){
						echo "Email was sent successfully ";
						redirect("login");
					}else{
						show_error($this->email->print_debugger());
					}
					 

				}
			}

		}




		public function logout(){
			unset($_SESSION["username"]);
			redirect('login');
			
				
			
		}
	}
 ?>