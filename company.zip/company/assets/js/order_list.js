$('#statusoption').on('change', function() {
	this.form.submit();
});	